#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>

using namespace std;

//the definition of the binary tree
template <class T>
class TreeNode {
public:
    T val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(T x) :val(x), left(NULL), right(NULL) {}
};



template <class T>
void preorderTraversal(TreeNode<T> *root){//the preorder Traversal
    stack<TreeNode<T>*> treeStack;
    TreeNode<T> *it=root;
    while(it||!treeStack.empty()){
        while(it){
            cout<<it->val<<" ";
            treeStack.push(it);
            it=it->left;
        }
        if(!treeStack.empty()){
            it=treeStack.top();
            treeStack.pop();
            it=it->right;
        }
    }
}

template <class T>
void inorderTraversal(TreeNode<T> *root){//the inorder Traversal
    stack<TreeNode<T>*> treeStack;
    TreeNode<T> *it=root;
    while (it||!treeStack.empty()) {
        while(it){
            treeStack.push(it);
            it=it->left;
        }
        if(!treeStack.empty()){
            it=treeStack.top();
            treeStack.pop();
            cout<<it->val<<" ";
            it=it->right;
        }
    }
}

template <class T>
void postorderTraversal(TreeNode<T> *root){//the postorder Traversal
    stack<TreeNode<T>*> treeStack;
    TreeNode<T> *it=root;
    stack<TreeNode<T>*> backStack;
    treeStack.push(it);
    while(!treeStack.empty()){
        it=treeStack.top();
        treeStack.pop();
        backStack.push(it);
        if(it->left) treeStack.push(it->left);
        if(it->right) treeStack.push(it->right);
    }
    while(!backStack.empty()){
        it=backStack.top();
        cout<<it->val<<" ";
        backStack.pop();
    }
}

template <class T>
void createBTinPreorder(TreeNode<T> *root,char* &input){//create the tree in preorder
    if(*input==' '){
        input++;
        return;
    }
    root->val=*input;
    input++;
    if(*input!=' ')root->left=new TreeNode<char>(' ');
    createBTinPreorder(root->left,input);
    if(*input!=' ')root->right=new TreeNode<char>(' ');
    createBTinPreorder(root->right,input);
    return ;
}

int main(){
    char* input=new char[100];
    cout<<"enter the the tree in preorder traversal,space for null"<<endl;
    if(!input) {
        cout<<"no enough memory"<<endl;
        return -1;
    }
    cin.getline(input,100);
    TreeNode<char> *root=new TreeNode<char>(' ');//initialize the root node of the tree
    if(*input==' ') root=nullptr;
    createBTinPreorder(root,input);//create the tree from the input
    cout<<"the preorder traversal without recursion:     ";
    preorderTraversal(root);
    cout<<endl;
    cout<<"the inorder traversal without recursion:     ";
    inorderTraversal(root);
    cout<<endl;
    cout<<"the postorder traversal without recursion:     ";
    postorderTraversal(root);
    cout<<endl;
    return 0;
}
