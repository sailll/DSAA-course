#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>

using namespace std;

//the definition of the binary tree
template <class T>
class TreeNode {
public:
    T val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(T x) :val(x), left(NULL), right(NULL) {}
};



template <class T>
void preorderTraversal(TreeNode<T> *root){//the preorder Traversal
    if(!root) return ;
    cout<<root->val<<" ";
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

template <class T>
void inorderTraversal(TreeNode<T> *root){//the inorder Traversal
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}

template <class T>
void postorderTraversal(TreeNode<T> *root){//the postorder Traversal
    if(!root) return ;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout<<root->val<<" ";
}

template <class T>
void createBTinPreorder(TreeNode<T> *root,char* &input){//create the tree in preorder
    if(*input==' '){
        input++;
        return;
    }
    root->val=*input;
    input++;
    if(*input!=' ')root->left=new TreeNode<char>(' ');
    createBTinPreorder(root->left,input);
    if(*input!=' ')root->right=new TreeNode<char>(' ');
    createBTinPreorder(root->right,input);
    return ;
}

int main(){
    char* input=new char[100];
    cout<<"enter the the tree in preorder traversal,space for null"<<endl;
    if(!input) {
        cout<<"no enough memory"<<endl;
        return -1;
    }
    cin.getline(input,100);
    TreeNode<char> *root=new TreeNode<char>(' ');//initialize the root node of the tree
    if(*input==' ') root=nullptr;
    createBTinPreorder(root,input);//create the tree from the input
    cout<<"the preorder traversal:     ";
    preorderTraversal(root);
    cout<<endl;
    cout<<"the inorder traversal:     ";
    inorderTraversal(root);
    cout<<endl;
    cout<<"the postorder traversal:     ";
    postorderTraversal(root);
    cout<<endl;
}
