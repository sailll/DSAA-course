#include <cstdio>
#include <iostream>

using namespace std;

template <class T>
class circularQueue {//定义循环队列
    static const int capacity=2;
    T ar[capacity];
    int front,rear,size;
public:
    circularQueue(){//初始化
        this->front=0;//头index
        this->rear=capacity-1;//尾index
        this->size=0;//当前数据量
    }
    T top(){//访问头元素
        return ar[front];
    }
    
    static int succ(int val){//形成环形结构，到了尾部后为零
        if(++val==capacity) val=0;
        return val;
    }
    
    bool isfull(){//队列是否满了
        if(size==capacity) return true;
        else return false;
    }
    
    bool isEmtpy(){//队列是否空
        if(size==0) return true;
        else return false;
    }
    
    void enqueue(T ele){//入队操作
        if(isfull()){
            cerr<<"the queue is full"<<endl;
            return ;
        }
        else{
            size++;
            rear=succ(rear);
            ar[rear]=ele;
        }
    }
    
    void dequeue(){//出队操作
        if(isEmtpy()){
            cerr<<"the queue is empty"<<endl;
            return;
        }
        else{
            size--;
            front=succ(front);
        }
    }
};
int main(){
    circularQueue<int> myq;
    myq.dequeue();//出队
    myq.enqueue(3);//连续入队
    myq.enqueue(4);
    myq.enqueue(5);
    cout<<myq.top()<<endl;//输出头部元素
}