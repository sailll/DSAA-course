#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

template<class T>
struct stack{
public:
    int len=0;
    int n=0;
    T *a=new T[len];
    stack(int _len){//有参构造函数
        this->len=_len;
    }
    stack(){//默认构造函数
    }
    void push(T x){//入栈
        a[n]=x;
        ++n;
    }
    bool empty(){//判断是否为空
        return n==0;
    }
    T top(){//访问栈顶
        if(!empty()) return a[n-1];
        else throw string("stack emtpy!");
    }
    void pop(){//出栈
        if(!empty()) --n;
        else throw string("stack emtpy!");
    }
};

string decimalToOctonary (unsigned int n){
    if(n==0) return "0";
    const int oct=8;
    string Octonary;
    stack<char> mystack;
    while(n){
        mystack.push('0'+n%oct);//入栈
        n/=oct;
    }
    while (!mystack.empty()) {
        Octonary+=mystack.top();//依次出栈
        mystack.pop();
    }
    return Octonary;
}

int main(){
    printf("enter the postive decimal number you want to convert\n");
    unsigned int n;
    scanf("%d",&n);
    cout<<decimalToOctonary(n)<<endl;//输出结果
    return 0;
}