#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <map>

using namespace std;

template<class T>
struct stack{
public:
    int len=0;
    int n=0;
    T *a=new T[len];
    stack(int _len){//有参构造函数
        this->len=_len;
    }
    stack(){//默认构造函数
    }
    void push(T x){//入栈
        if(isFull()) return;
        a[n]=x;
        ++n;
    }
    
    bool isFull(){
        return n==len;
    }
    bool empty(){//判断是否为空
        return n==0;
    }
    T top(){//访问栈顶
        if(!empty()) return a[n-1];
        else throw string("stack emtpy");
    }
    void pop(){//出栈
        if(!empty()) --n;
        else throw string("stack emtpy");
    }
};

template <class T>
struct ListNode{//定义模版node
    T val;
    ListNode* next;
    ListNode(T _val){//有参构造函数
        this->val=_val;
        next=nullptr;
    }
    ListNode(){//无参构造函数
        next=nullptr;
    }
};

template <class T>
class queue {//定义队列
    
    ListNode<T> *front=new ListNode<T>();//头指针
    ListNode<T> *rear;//尾部指针
    
public:
    int len=0;
    T top(){//访问队列头部元素
        if(len==0) throw string("nothing in the queue");
        return front->next->val;
    }
    
    bool isEmpty(){
        return len==0;
    }
    queue(){
        rear=front;
        len=0;
    }
    void enqueue(ListNode<T> *ele){//入队操作
        rear->next=ele;
        rear=rear->next;
        len++;
    }
    
    void dequeue(){//出队操作
        try {
            if(len==0) throw string("no ele to be dequeued");
            front=front->next;
            len--;
        } catch (string s) {
            cout<<s<<endl;
        }
    }
    
    
    queue(ListNode<T> *_front){//初始化
        this->front=_front;
        this->rear=front;
        len=1;
    }
    
    void destory(){//销毁队列
        while (front) {
            ListNode<T> *t=front;
            front=front->next;
            free(t);
        }
        len=0;
    }
};

void parkManage(){
    printf("enter the capacity of the park\n");//输入停车场容量
    int n;
    scanf("%d",&n);
    stack<int> inpark(n);//模拟停车场的栈
    stack<int> outpark(n);//模拟停车场出来的栈
    queue<int> alleyway;//模拟通道的队列
    char oper;//操作代码
    int plateNumber;//车牌号
    int time;//时间
    int price;//每分钟的价钱
    map<int,pair<int, int>> timerecord;//纪录每辆车的入场和出场时间
    printf("enter the price inside park /min\n");
    scanf("%d",&price);
    printf("enter the operations\n");
    while(1){
        cin>>oper;
        scanf("%d",&plateNumber);
        scanf("%d",&time);
        switch (oper) {
            case 'A':
                if(!inpark.isFull()){
                    inpark.push(plateNumber);
                    timerecord[plateNumber].first=time;
                    printf("the place of the car in the park is %d\n",inpark.n);
                }
                else{
                    alleyway.enqueue(new ListNode<int>(plateNumber));
                    timerecord[plateNumber].first=0;
                    timerecord[plateNumber].second=0;
                    printf("the place of the car in the alleyway is %d\n",alleyway.len);
                }
                break;
            case 'D':
                while(!inpark.empty()&&inpark.top()!=plateNumber){//寻找车牌
                    outpark.push(inpark.top());
                    inpark.pop();
                }
                if(!inpark.empty()){
                    timerecord[inpark.top()].second=time;//出停车场的时间
                    int st=timerecord[inpark.top()].first;
                    int et=timerecord[inpark.top()].second;
                    printf("starting time: %d,end time:%d,%d should be paid\n",st,et,(et-st)*price);
                    inpark.pop();
                    while (!outpark.empty()) {//把缓冲的的车辆重新放进停车场
                        inpark.push(outpark.top());
                        outpark.pop();
                    }
                    if(!alleyway.isEmpty()){//如果通道非空，那么通道中的第一辆车进入停车场
                        inpark.push(alleyway.top());
                        timerecord[alleyway.top()].first=time;
                        alleyway.dequeue();
                    }
                }
                else{
                    queue<int> buffer;//缓冲队列
                    while(!alleyway.isEmpty()&&alleyway.top()!=plateNumber){
                        buffer.enqueue(new ListNode<int>(alleyway.top()));
                        alleyway.dequeue();
                    }
                    if(!alleyway.isEmpty()){
                        printf("never enter the park no need to pay\n");
                        alleyway.dequeue();//如果找到就出队
                    }
                    else{//否则输出没有该车
                        printf("car not found\n");
                    }
                    while (!buffer.isEmpty()) {//把缓冲队列的元素放回通道
                        alleyway.enqueue(new ListNode<int>(buffer.top()));
                        buffer.dequeue();
                    }
                }
                break;
            case 'E':
                printf("input end\n");
                return;
        }
    }
}
int main(){
    parkManage();
}

