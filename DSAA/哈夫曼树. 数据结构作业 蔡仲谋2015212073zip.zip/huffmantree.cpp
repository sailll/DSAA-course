#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>

using namespace std;

//the definition of the binary tree

template <class T>
class TreeNode {
public:
    T val;
    TreeNode* left;
    TreeNode* right;
    float power;
    TreeNode(T x,float _power) :power(_power),val(x), left(NULL), right(NULL) {}
    bool operator < (const TreeNode<T> &a) const
    {
        return a.power>power;
    }
};

struct compare{
    bool operator()(const TreeNode<char>* a,const TreeNode<char>* b){
        return a->power>b->power;
    }
};


//find the depth of a binary tree
template <class T>
void getDepthOfBT(TreeNode<T> *root,int &depth){//using reference
    if(!root) return ;
    int ld=0;
    getDepthOfBT(root->left,ld);
    int rd=0;
    getDepthOfBT(root->right,rd);
    depth=max(ld,rd)+1;
}

template <class T>
int getDepthOfBT(TreeNode<T> *root){//without using reference
    if(!root) return 0;
    return max(getDepthOfBT(root->left),getDepthOfBT(root->right))+1;
}


//count the number of leaf of a binary tree
template <class T>
void CountLeaf(TreeNode<T> *root,int &count){//using reference
    if(!root) return;
    if(!root->left&&!root->right) count++;
    CountLeaf(root->left,count);
    CountLeaf(root->right,count);
}

template <class T>
int CountLeaf(TreeNode<T> *root){//without using reference
    if(!root) return 0;
    if(!root->left&&!root->right) return 1;
    return CountLeaf(root->left)+CountLeaf(root->right);
}

template <class T>
void preorderTraversal(TreeNode<T> *root){//the preorder Traversal
    if(!root) return ;
    cout<<root->val<<" ";
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

template <class T>
void inorderTraversal(TreeNode<T> *root){//the inorder Traversal
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}

template <class T>
void postorderTraversal(TreeNode<T> *root){//the postorder Traversal
    if(!root) return ;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout<<root->val<<" ";
    
}

TreeNode<char>* createHuffmanTree(priority_queue<TreeNode<char>*,vector<TreeNode<char>* >,compare> data){
    TreeNode<char>* root;
    TreeNode<char>* n1;
    TreeNode<char>* n2;
    TreeNode<char>* parent;
    while (data.size()>1) {
        n1=data.top();
        data.pop();
        n2=data.top();
        data.pop();
        parent=new TreeNode<char>(' ',n1->power+n2->power);
        parent->left=n1;
        parent->right=n2;
        data.push(parent);
    }
    root=data.top();
    return root;
}

float countWPF(TreeNode<char> *root,int depth=0){
    if(!root) return 0;
    if(!root->left&&!root->right){
      return depth*(root->power);
    }
    return countWPF(root->left,depth+1)+countWPF(root->right,depth+1);
}

int main(){
    priority_queue<TreeNode<char>*,vector<TreeNode<char>* >,compare> data;
    cout<<"enter the n"<<endl;
    int n;
    cin>>n;
    for(int i=0;i<n;++i){
        char name;
        cin>>name;
        float power;
        cin>>power;
        data.push(new TreeNode<char>(name,power));
    }
    TreeNode<char> *root=createHuffmanTree(data);
    cout<<"the least wpl is ";
    cout<<countWPF(root)<<endl;
}


