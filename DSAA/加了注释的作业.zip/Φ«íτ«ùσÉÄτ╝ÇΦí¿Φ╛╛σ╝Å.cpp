#include <vector>
#include <string>
#include <cstdio>
#include <iostream>
using namespace std;
template<class T>
struct stack{
public:
    int len=0;
    int n=0;
    T *a=new T[len];
    stack(int _len){//有参构造函数
        this->len=_len;
    }
    stack(){//默认构造函数
    }
    void push(T x){//入栈
        a[n]=x;
        ++n;
    }
    bool empty(){//判断是否为空
        return n==0;
    }
    T top(){//访问栈顶
        if(!empty()) return a[n-1];
        else throw string("wrong expression");
    }
    void pop(){//出栈
        if(!empty()) --n;
        else throw string("wrong expression");
    }
};
char oper[4]={'+','-','*','/'};//定义操作符

bool judgeNumber(const string &c){//判断是否整数
    int bg=0;
    if(c[0]=='-') bg=1;
    for(int i=bg;i<c.length();++i){
        if(c[i]>'9'||c[i]<'0') return false;
    }
    return true;
}
int judgeOperand(const string &c){//判断是否操作符
    if(c.length()!=1) return 0;
    for(int i=0;i<4;++i){
        if(c[0]==oper[i]) return i+1;
    }
    return 0;
}
int atoi(string s){//把string转int，可以判断负数
    int ans=0;
    int bg=0;
    int ex=1;
    bool flag=false;
    if(s[0]=='-'){
        bg=1;
        flag=true;
    }
    for(int i=s.length()-1;i>=bg;--i){
        ans+=((s[i]-'0')*ex);
        ex*=10;
    }
    return flag?-ans:ans;
}
int evaluatePostfix(vector<string> s){//计算后缀表达式
    stack<int> postfix;//定义栈
    for(int i=0;i<s.size();++i){
        if(judgeNumber(s[i])) postfix.push(atoi(s[i]));//如果为int，入栈
        if(judgeOperand(s[i])){//如果是操作符
            try {//防止异常
                int ex1=postfix.top();postfix.pop();//把第一个操作数出栈
                int ex2=postfix.top();postfix.pop();//把第二个操组数出栈
                int ans;
                switch (judgeOperand(s[i])) {//计算相应操作符结果
                    case 1:ans=ex2+ex1; break;
                    case 2:ans=ex2-ex1; break;
                    case 3:ans=ex2*ex1; break;
                    case 4:ans=ex2/ex1; break;
                }
                postfix.push(ans);//把结果入栈
            } catch (string s) {//如果有异常 输出“wrong expression"
                cerr<<s<<endl;
                return -1;
            }
        }
    }
    return postfix.top();//返回最终结果，就是栈顶元素
}
int main(){
    vector<string> s;//定义表达式的string数组
    int n;
    cout<<"enter the total number of the operands and operators"<<endl;//输入数组的长度
    scanf("%d",&n);
    for(int i=0;i<n;++i){
        string tmp;
        cin>>tmp;
        s.push_back(tmp);
    }//把表达式输入
    cout<<evaluatePostfix(s)<<endl;//输出最终结果
    return 0;
}//本程序可以计算大数以及负数的后缀表达式，包括加减乘除四种运算法则
