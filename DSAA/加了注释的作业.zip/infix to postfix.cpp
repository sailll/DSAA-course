#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <cstdio>
#include <iostream>

using namespace std;

template<class T>
struct stack{
public:
    int len=0;
    int n=0;
    T *a=new T[len];
    stack(int _len){//有参构造函数
        this->len=_len;
    }
    stack(){//默认构造函数
    }
    void push(T x){//入栈
        a[n]=x;
        ++n;
    }
    bool empty(){//判断是否为空
        return n==0;
    }
    T top(){//访问栈顶
        if(!empty()) return a[n-1];
        else throw string("wrong expression");
    }
    void pop(){//出栈
        if(!empty()) --n;
        else throw string("wrong expression");
    }
};
char oper[6]={'+','-','*','/','(',')'};//定义操作符

int judgeOperand(const char &c){//判断是否为操作符
    for(int i=0;i<6;++i){
        if(c==oper[i]) return i+1;
    }
    return 0;
}

unsigned int cmpOperand(const char& c){//输出操作符优先级，分为0，1，2
    return (judgeOperand(c)-1)/2;
}

bool judgeVar(char c){//判断是否为代数变量
    if(c>='a'&&c<='z') return true;
    if(c>='A'&&c<='Z') return true;
    else return false;
}

string convertInfixToPostfix(const string& s){//把中缀表达式转成后缀表达式
    stack<char> oper;
    string ans;
    for(int i=0;i<s.length();++i){
        if(judgeVar(s[i])){//如果是变量，输出
            ans+=s[i];
            continue;
        }
        if(judgeOperand(s[i])){
            if(oper.empty()||s[i]=='(') oper.push(s[i]);//如果遇到左括号或者栈为空，入栈
            else{
                if(s[i]==')'){//如果遇到右括号，那就一次出栈输出，直到遇到左括号，但左括号不输出
                    while(oper.top()!='('){
                        ans+=oper.top();
                        oper.pop();
                    }
                    oper.pop();
                    continue;
                }
                if(cmpOperand(s[i])>cmpOperand(oper.top()))oper.push(s[i]);//如果比当前操作符比栈顶操作符优先度高，入栈
                else{
                    while(!oper.empty()&&oper.top()!='('&&cmpOperand(s[i])<=cmpOperand(oper.top())){
                        ans+=oper.top();//否则出栈，直到遇到操作符优先级高的操作符或者栈为空
                        oper.pop();
                    }
                    oper.push(s[i]);
                }
            }
        }
    }
    while(!oper.empty()){//如果非空，把所有操作符输出
        ans+=oper.top();
        oper.pop();
    }
    return ans;//返回后缀表达式
}
int main(){
    cout<<"input the infix"<<endl;
    string infix;
    cin>>infix;
    cout<<convertInfixToPostfix(infix)<<endl;//输出结果
    return 0;
}
