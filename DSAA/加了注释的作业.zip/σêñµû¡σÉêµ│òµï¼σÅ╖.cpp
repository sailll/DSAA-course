#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <map>

using namespace std;

template<class T>
struct node {
public:
    T val;
    node<T>* next;
    node(T _x) {
        this->val=_x;
    }
    node() {
        
    }
};//定义模版节点

template<class T>
class stack {//定义模版栈
public:
    node<T>* s=new node<T>(' ');//头节点
    bool empty() {//判断是否为空
        return s->next == NULL;
    }
    void push(T x) {//入栈过程
        node<T>* tmpcell = new node<T>;
        if (tmpcell == NULL) {
            cerr << "out of space" << endl;
            return;
        }
        else {
            tmpcell->val = x;
            tmpcell->next = s->next;
            s->next = tmpcell;
        }
    }
    T top(){//访问栈顶
        if (!empty()) return s->next->val;
        else return s->val;
    }
    void pop() {//出栈
        if (empty()) return;
        node<T>* firstcell = s->next;
        s->next = s->next->next;
        free(firstcell);
    }
    stack(){
        
    }
};

bool isValid(string s) {
    map<char,char> dict;//构造括号对应的法则
    dict['(']=')';
    dict['{']='}';
    dict['[']=']';
    stack<char> judge;//初始化栈
    int len=s.length();
    for(int i=0;i<len;++i){
        bool flag=false;
        for(auto it=dict.begin();it!=dict.end();++it){
            if(s[i]==it->first){
                judge.push(s[i]);//存在左括号就入栈
                flag=true;
            }
            
        }
        if(!flag){//如果存在左括号
            if(judge.empty()) return false;//如果为空，表达式错误
            if(dict[judge.top()]==s[i]) judge.pop();//如果存在栈顶对应的右括号，那就出栈
            else return false;
        }
    }
    if(judge.empty()) return true;//如果最后栈为空，表达式正确
    return false;//否则错误
}

int main(){
    string s;
    cin>>s;//输入表达式
    cout<<isValid(s)<<endl;//输出结果
    return 0;
}