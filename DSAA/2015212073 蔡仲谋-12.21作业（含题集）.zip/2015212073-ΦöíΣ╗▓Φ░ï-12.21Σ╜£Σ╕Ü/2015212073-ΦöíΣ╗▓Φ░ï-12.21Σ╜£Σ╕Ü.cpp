#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
using namespace std;


void input(int n,vector<int> &key){//the input array process
    for(int i=0;i<n;++i){
        int cval;
        cin>>cval;
        key.push_back(cval);
    }
}


//the sentinal search
int sentinalSearch(int key,vector<int> array,int n){
    array.push_back(key);//add the sentinal , if it is iterated ,the search fail
    int i=0;
    while(array[i++]!=key){};
    if(i==n+1) i=0;//if i==n+1 ,it means that the key is not found,it will return -1
    return i-1;
}

int binarySearch(int key, vector<int> &array){
    sort(array.begin(),array.end());//use the sort algorithm to do satisfy the condition for binary search,but it reality I do not recommend to do this because it is not worthwhile
    int start=0;
    int end=int(array.size())-1;
    int mid;
    while(start<end){
        mid=start+(end-start)/2;
        if(array[mid]<key) start=mid+1;
        if(array[mid]>key) end=mid-1;
        if(array[mid]==key) return mid;
    }
    return -1;//which means it was not found
}


template <class T>
class TreeNode{//define the treenode
    
public:
    T val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(T _val):val(_val),left(NULL),right(NULL){}
    TreeNode(){}
    
};


template <class T>
void inorderTraversal(TreeNode<T>* const &root){//the inorder traversal of a BST will return a ordered sequence
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}


template <class T>//create the binary search tree
void createBST(TreeNode<T>* &root,const vector<T> &array){
    if(array.size()==0) return;
    root->val=array[0];
    for(int i=1;i<array.size();++i){
        auto pre=root;//use a pre pointer to denote the predecessor
        auto it=root;//use it to denote the current pointer
        bool flag=true;//use a flag to denote the right or the left
        while(it){
            if(array[i]>(it->val)) {
                flag=true;
                pre=it;
                it=it->right;
            }
            else{
                flag=false;
                pre=it;
                it=it->left;
            }
        }
        it=new TreeNode<T>(array[i]);
        if(flag) pre->right=it;
        else pre->left=it;
    }
}

template <class T>
TreeNode<T>* searchBST(TreeNode<T>* &root,T key){
    if(!root||root->val==key){
        return root;
    }
    if(key>root->val) return searchBST(root->right, key);
    else return searchBST(root->left,key);
}


void testSentinalSearch(){
    //sentinal search
    cout<<"enter the element to be searched"<<endl;
    int key;
    cin>>key;
    vector<int> array;
    cout<<"enter the length of the array and the array elements"<<endl;
    int n;//the length of the array
    cin>>n;
    input(n,array);
    cout<<"using sentinal search the index of the key is "<<sentinalSearch(key,array,n)<<endl;
}

void testBinarySearch(){
    cout<<"enter the element to be searched"<<endl;
    int key;
    cin>>key;
    int n;
    cout<<"enter the length and an ordered array for binary search"<<endl;
    cin>>n;
    vector<int> newarrayForBS;
    input(n, newarrayForBS);
    cout<<"using binary search the index of the key is "<<binarySearch(key, newarrayForBS)<<endl;
}

void testBST(){
    cout<<"enter the element to be searched"<<endl;
    int key;
    cin>>key;
    int n;
    cout<<"enter the length and an  array for BST"<<endl;
    cin>>n;
    vector<int> array;
    input(n, array);
    TreeNode<int> *root=new TreeNode<int>(0);
    createBST(root, array);
    cout<<"when the BST is created ,the inorderTraversal will be an increasing order sequence as follows"<<endl;
    inorderTraversal(root);
    cout<<endl;
    TreeNode<int> *k=searchBST(root, key);
    if(k)cout<<"it was found"<<endl;
    else cout<<"not found"<<endl;
}
int main(){
    testSentinalSearch();
    testBinarySearch();
    testBST();
}
