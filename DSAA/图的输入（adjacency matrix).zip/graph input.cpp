#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
#define MAXV 100
using namespace std;

//the definition of the binary tree



void createGraph(){
    cout<<"enter the number of the vectexs and edges"<<endl;
    int nofv,nofe;
    cin>>nofv>>nofe;
    int dict[nofv][nofv];
    memset(dict,0,sizeof(dict));
    cout<<"enter the edge and its power"<<endl;
    for(int i=0;i<nofe;++i){
        int a,b;
        float power;
        cin>>a>>b>>power;
        dict[a][b]=power;
    }
    cout<<"so the adjacency matrix is "<<endl;
    for(int i=0;i<nofv;++i){
        for(int j=0;j<nofv;++j){
            cout<<dict[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    createGraph();
}


