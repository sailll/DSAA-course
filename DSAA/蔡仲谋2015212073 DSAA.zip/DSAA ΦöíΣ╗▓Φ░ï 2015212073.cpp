#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

template <class T>
struct ListNode{//定义模版链表
    T val;
    ListNode* next;
    ListNode(T _val){//有参构造函数
        this->val=_val;
        next=nullptr;
    }
    ListNode(){//无参构造函数
        next=nullptr;
    }
};

template <class T>
class queue {//定义队列
    
    ListNode<T> *front=new ListNode<T>();//头指针
    ListNode<T> *rear;//尾部指针
    int len=0;
    
public:
    void top(){//访问队列头部元素
        try {
            if(len==0) throw string("no ele in the queue");
            cout<<front->next->val<<endl;
        } catch (string s) {
            cout<<s<<endl;
        }
        
    }
    
    queue(){
        rear=front;
        len=0;
    }
    void enqueue(ListNode<T> *ele){//入队操作
        rear->next=ele;
        rear=rear->next;
        len++;
    }
    
    void dequeue(){//出队操作
        try {
            if(len==0) throw string("no ele to be dequeued");
            front=front->next;
            len--;
        } catch (string s) {
            cout<<s<<endl;
        }
    }
    
    
    queue(ListNode<T> *_front){//初始化
        this->front=_front;
        this->rear=front;
        len=1;
    }
    
    void destory(){//销毁队列
        while (front) {
            ListNode<T> *t=front;
            front=front->next;
            free(t);
        }
        len=0;
    }
};

int main(){
    queue<int> myqueue;//initialize
    ListNode<int> *ele=new ListNode<int>(4);
    myqueue.enqueue(ele);//入队
    myqueue.top();//访问队头部元素
    myqueue.dequeue();//出队
    myqueue.top();//显示异常处理
    myqueue.dequeue();//异常处理
    myqueue.destory();//销毁队列
}
