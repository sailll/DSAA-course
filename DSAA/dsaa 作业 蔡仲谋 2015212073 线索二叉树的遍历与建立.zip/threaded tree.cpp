#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>

using namespace std;

//the definition of the binary tree

class TreeNode {
public:
    char val;
    bool ltag;
    bool rtag;
    TreeNode* left;
    TreeNode* right;
    TreeNode(char x) :val(x), left(NULL), right(NULL), ltag(false), rtag(false) {}
};

TreeNode *pre=new TreeNode(' ');


void inorderTraversal(TreeNode *root){//the inorder Traversal
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}


void createBTinPreorder(TreeNode *root,char* &input){//create the tree in preorder
    if(*input==' '){
        input++;
        return;
    }
    root->val=*input;
    input++;
    if(*input!=' ')root->left=new TreeNode(' ');
    createBTinPreorder(root->left,input);
    if(*input!=' ')root->right=new TreeNode(' ');
    createBTinPreorder(root->right,input);
    return ;
}


void Inthreading(TreeNode *root){
    if(root){
        Inthreading(root->left);
        if(!root->left){
            root->ltag=true;
            root->left=pre;
        }
        if(!pre->right){
            pre->rtag=true;
            pre->right=root;
        }
        pre=root;
        Inthreading(root->right);
    }
}


void InOrderThreading(TreeNode *Thrt,TreeNode *root){
    Thrt->ltag=false;
    Thrt->rtag=true;
    Thrt->right=Thrt;
    if(!root) Thrt->left=Thrt;
    else{
        Thrt->left=root;
        pre=Thrt;
        Inthreading(root);
        pre->right=Thrt;
        pre->rtag=true;
        Thrt->right=pre;
    }
}

void inOrderThrtTraversal(TreeNode *Thrt){
    TreeNode *it=Thrt->left;
    while(it!=Thrt){
        while (!it->ltag) it=it->left;
        cout<<it->val<<" ";
        while (it->rtag&&it->right!=Thrt){
            it=it->right;
            cout<<it->val<<" ";
        }
        it=it->right;
    }
    cout<<endl;
}

int main(){
    char* input=new char[100];
    cout<<"enter the the tree in preorder traversal,space for null"<<endl;
    if(!input) {
        cout<<"no enough memory"<<endl;
        return -1;
    }
    cin.getline(input,100);
    TreeNode *root=new TreeNode(' ');//initialize the root node of the tree
    if(*input==' ') root=nullptr;
    createBTinPreorder(root,input);//create the tree from the input
    TreeNode *Thrt=new TreeNode(' ');
    InOrderThreading(Thrt,root);
    inOrderThrtTraversal(Thrt);
}
