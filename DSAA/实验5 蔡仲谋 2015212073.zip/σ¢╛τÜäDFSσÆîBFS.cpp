#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
#define MAXV 100
using namespace std;

//the definition of the binary tree
enum color{white,gray,black};

class vertex{
public:
    int id;
    vector<int> adjacencylist;
    color c;
    int predecessor;
    int distance;
    vertex(int _id,vector<int> _l,color _c,int _predecessor,int _dis):id(_id),adjacencylist(_l),c(_c),predecessor(_predecessor),distance(_dis){}
};

void createGraph(vector<vertex> &graph){
    int n;
    cout<<"enter the number of the vertex"<<endl;
    cin>>n;
    for(int i=0;i<n+1;++i){
        graph.push_back(*new vertex(i,*new vector<int>,white,-1,0xffffffff));
    }
    cout<<"enter the number of edges"<<endl;
    int nofe;
    cin>>nofe;
    cout<<"enter the edges using pair"<<endl;
    for(int i=0;i<nofe;++i){
        int u,v;
        cin>>u>>v;
        graph[u].adjacencylist.push_back(v);
        graph[v].adjacencylist.push_back(u);
    }
}

void BFSedgeset(vector<vertex> &graph,int root){
    graph[root].distance=0;
    graph[root].c=gray;
    graph[root].predecessor=-1;
    queue<vertex> q;
    q.push(graph[root]);
    while(!q.empty()){
        vertex u=q.front();
        q.pop();
        cout<<"";
        for(auto i:u.adjacencylist){
            if(graph[i].c==white){
                cout<<u.id<<"--"<<graph[i].id<<" ";
                graph[i].c=gray;
                graph[i].distance=u.distance+1;
                graph[i].predecessor=u.id;
                q.push(graph[i]);
            }
        }
        u.c=black;
    }
}

void restore(vector<vertex> &graph){
    for(int i=0;i<graph.size();++i){
        graph[i].c=white;
    }
}

void BFS(vector<vertex> &graph){
    int root;
    cout<<"enter the root number for BFS"<<endl;
    cin>>root;
    cout<<"the BFS is ";
    graph[root].distance=0;
    graph[root].c=gray;
    graph[root].predecessor=-1;
    queue<vertex> q;
    q.push(graph[root]);
    while(!q.empty()){
        vertex u=q.front();
        cout<<u.id<<" ";
        q.pop();
        cout<<"";
        for(auto i:u.adjacencylist){
            if(graph[i].c==white){
                graph[i].c=gray;
                graph[i].distance=u.distance+1;
                graph[i].predecessor=u.id;
                q.push(graph[i]);
            }
        }
        u.c=black;
    }
    restore(graph);
    cout<<endl;
    cout<<"the edge set of BFS spanning tree is ";
    BFSedgeset(graph, root);
}



void show(vector<vertex> &graph){
    auto n=graph.size();
    int matrix[n+1][n+1];
    memset(matrix,0,sizeof(matrix));
    for(int i=1;i<n;++i){
        for(auto j:graph[i].adjacencylist){
            matrix[i][j]=1;
        }
    }
    for(int i=1;i<n;++i){
        for(int j=1;j<n;++j){
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
    for(int i=1;i<n;++i){
        cout<<graph[i].id<<" "<<graph[i].distance<<endl;
    }
}

void path(vector<vertex> &graph,int s,int v){
    if(s==v) cout<<s<<" ";
    else if(graph[v].predecessor==-1){
        cout<<"no such path";
    }
    else{
        path(graph, s, graph[v].predecessor);
        cout<<v<<" ";
    }
}

void DFS(vector<vertex> &graph,int root){
    cout<<graph[root].id<<" ";
    graph[root].c=gray;
    for(auto i:graph[root].adjacencylist){
        if(graph[i].c==white){
            graph[i].c=gray;
            DFS(graph,i);
        }
        graph[i].c=black;
    }
}

void DFSedgeset(vector<vertex> &graph,int root){
    graph[root].c=gray;
    for(auto i:graph[root].adjacencylist){
        if(graph[i].c==white){
            cout<<graph[root].id<<"--"<<graph[i].id<<" ";
            graph[i].c=gray;
            DFSedgeset(graph,i);
        }
        graph[i].c=black;
    }
}



int main(){
    vector<vertex> graph;
    createGraph(graph);
    int root;
    cout<<"enter the root for DFS "<<endl;
    cin>>root;
    cout<<"the DFS is ";
    DFS(graph, root);
    restore(graph);
    cout<<endl;
    cout<<"the edge set of DFS spanning tree is ";
    DFSedgeset(graph, root);
    cout<<endl;
    restore(graph);
    BFS(graph);
    cout<<endl;
}
