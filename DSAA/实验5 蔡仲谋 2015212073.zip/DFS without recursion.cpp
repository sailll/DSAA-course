#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>

using namespace std;

enum color{white,gray,black};

class vertex{
public:
    int id;
    vector<int> adjacencylist;
    color c;
    int predecessor;
    int distance;
    vertex(int _id,vector<int> _l,color _c,int _predecessor,int _dis):id(_id),adjacencylist(_l),c(_c),predecessor(_predecessor),distance(_dis){}
};

template<class T>
struct stack{
public:
    int len=0;
    int n=0;
    T *a=new T[len];
    stack(int _len){//有参构造函数
        this->len=_len;
    }
    stack(){//默认构造函数
    }
    void push(T x){//入栈
        a[n]=x;
        ++n;
    }
    bool empty(){//判断是否为空
        return n==0;
    }
    T top(){//访问栈顶
        if(!empty()) return a[n-1];
        else throw string("wrong expression");
    }
    void pop(){//出栈
        if(!empty()) --n;
        else throw string("wrong expression");
    }
};

void createGraph(vector<vertex> &graph){
    int n;
    cout<<"enter the number of the vertex"<<endl;
    cin>>n;
    for(int i=0;i<n+1;++i){
        graph.push_back(*new vertex(i,*new vector<int>,white,-1,0xffffffff));
    }
    cout<<"enter the number of edges"<<endl;
    int nofe;
    cin>>nofe;
    cout<<"enter the edges using pair"<<endl;
    for(int i=0;i<nofe;++i){
        int u,v;
        cin>>u>>v;
        graph[u].adjacencylist.push_back(v);
        graph[v].adjacencylist.push_back(u);
    }
    
}


void show(vector<vertex> &graph){
    auto n=graph.size();
    int matrix[n+1][n+1];
    memset(matrix,0,sizeof(matrix));
    for(int i=1;i<n;++i){
        for(auto j:graph[i].adjacencylist){
            matrix[i][j]=1;
        }
    }
    for(int i=1;i<n;++i){
        for(int j=1;j<n;++j){
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
    for(int i=1;i<n;++i){
        cout<<graph[i].id<<" "<<graph[i].distance<<endl;
    }
}

void path(vector<vertex> &graph,int s,int v){
    if(s==v) cout<<s<<" ";
    else if(graph[v].predecessor==-1){
        cout<<"no such path";
    }
    else{
        path(graph, s, graph[v].predecessor);
        cout<<v<<" ";
    }
}

void restore(vector<vertex> &graph){
    for(int i=0;i<graph.size();++i){
        graph[i].c=white;
    }
}

void DFSedgeset(vector<vertex> &graph,int root){
    stack<int> nodestack;
    nodestack.push(root);
    graph[root].c=gray;
    while(!nodestack.empty()){
        for(int i=0;i<graph[nodestack.top()].adjacencylist.size();++i){
            int j=graph[nodestack.top()].adjacencylist[i];
            if(graph[j].c==white){
                i=-1;
                graph[j].c=gray;
                cout<<nodestack.top()<<"--"<<graph[j].id<<" ";
                nodestack.push(j);
            }
        }
        graph[nodestack.top()].c=black;
        nodestack.pop();
    }
    
}

void DFSwithoutRecursion(vector<vertex> &graph){
    int root;
    cout<<"enter the root number"<<endl;
    cin>>root;
    stack<int> nodestack;
    nodestack.push(root);
    graph[root].c=gray;
    cout<<"DFS without recursion is: ";
    cout<<graph[root].id<<" ";
    while(!nodestack.empty()){
        for(int i=0;i<graph[nodestack.top()].adjacencylist.size();++i){
            int j=graph[nodestack.top()].adjacencylist[i];
            if(graph[j].c==white){
                i=-1;
                graph[j].c=gray;
                cout<<graph[j].id<<" ";
                nodestack.push(j);
            }
        }
        graph[nodestack.top()].c=black;
        nodestack.pop();
    }
    cout<<endl;
    cout<<"the edgeset of DFS spanning tree is ";
    restore(graph);
    DFSedgeset(graph,root);
}



int main(){
    vector<vertex> graph;
    createGraph(graph);
    DFSwithoutRecursion(graph);
    cout<<endl;
}
