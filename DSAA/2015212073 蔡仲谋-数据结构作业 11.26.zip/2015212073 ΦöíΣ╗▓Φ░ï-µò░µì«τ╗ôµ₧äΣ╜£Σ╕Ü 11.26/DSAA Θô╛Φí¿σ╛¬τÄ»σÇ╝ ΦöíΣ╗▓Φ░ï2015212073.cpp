#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <map>

using namespace std;
template <class T>
struct ListNode{//定义模版node
    T val;
    ListNode* next;
    ListNode(T _val){//有参构造函数
        this->val=_val;
        next=nullptr;
    }
    ListNode(){//无参构造函数
        next=nullptr;
    }
};
template <class T>
void initialize(ListNode<T>* head){
    int n;
    ListNode<T>* it=head;
    cout<<"enter the number of nodes in the linkedlist"<<endl;
    cin>>n;
    cout<<"enter all the element seperated by space"<<endl;
    for(int i=0;i<n;++i){
        T cval;
        cin>>cval;
        ListNode<T>* ne=new ListNode<T>(cval);
        it->next=ne;
        it=it->next;
    }
}

template <class T>
void traversal(ListNode<T>* head){
    ListNode<T>* it=head;
    while(it){
        cout<<it->val<<" ";
        it=it->next;
    }
    cout<<endl;
}

template <class T>
void visit(ListNode<T>* head,int k){
    int cnt=0;
    int pos=0;
    ListNode<T>* p=head;
    while(p){
        cnt++;
        cout<<"cnt = "<<cnt<<endl;
        p=p->next;
    }
    cout<<"the counting finished,the total length is "<<cnt<<endl;
    pos=cnt-k+1;
    if(pos>0){
        cnt=0;
        p=head;
        while(p){
            cnt++;
            cout<<"p points to "<<p->val<<endl;
            cout<<"cnt = "<<cnt<<endl;
            cout<<"pos = "<<pos<<endl;
            if(cnt==pos) break;
            p=p->next;
        }
        cout<<"the "<<k<<"th element from the back is "<<p->val<<endl;
    }
    else cout<<k<<"is larger than the length of the linkedlist"<<endl;
}

int main(){
    ListNode<char> *head=new ListNode<char>(' ');
    initialize(head);
    head=head->next;
    traversal(head);
    int k;
    cout<<"enter the value of k"<<endl;
    cin>>k;
    visit(head,k);
    return 0;
}

