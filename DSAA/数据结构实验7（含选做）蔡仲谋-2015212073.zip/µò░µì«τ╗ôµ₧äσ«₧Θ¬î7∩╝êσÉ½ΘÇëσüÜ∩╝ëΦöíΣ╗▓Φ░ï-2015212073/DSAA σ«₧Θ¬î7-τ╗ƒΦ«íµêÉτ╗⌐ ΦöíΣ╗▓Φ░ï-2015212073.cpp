#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <map>
#include <string>
#include <list>
#include <ctime>

using namespace std;

class Student{
public:
    int id;
    vector<int> grades;
    int total;
    string name;
    int rank;
    Student(int _id,vector<int> _grades,int _total,string _name):id(_id),grades(_grades),total(_total),name(_name){}
    void print(){
        cout<<"rank "<<rank<<" ";
        cout<<"id is "<<id<<" name is "<<name<<" total sum is "<<total<<" all subjects are : ";
        for(int i:grades) cout<<i<<" ";
        cout<<endl;
    }
};

bool operator <(const Student &a,const Student &b){
    return a.total<b.total;
}

void test(){
    cout<<"enter the number of subjects"<<endl;
    int m;
    cin>>m;
    cout<<"enter the number of the student"<<endl;
    int n;
    cin>>n;
    vector<Student> students;
    for(int i = 0 ;i< n;++i){
        cout<<"enter the id"<<endl;
        int _id;
        cin>>_id;
        cout<<"enter the name"<<endl;
        string _name;
        cin>>_name;
        cout<<"enter the subject grades"<<endl;
        vector<int> _grades;
        int _total = 0;
        for(int i = 0;i<m;++i){
            int cval;
            cin>>cval;
            _grades.push_back(cval);
            _total+=cval;
        }
        
        Student newStudnet = *new Student(_id,_grades,_total,_name);
        students.push_back(newStudnet);
    }
    sort(students.begin(),students.end());
    students[0].rank=1;
    for(int i = 1;i < n;++i){//set the rank
        if(students[i].total==students[i-1].total) students[i].rank=students[i-1].rank;
        else students[i].rank=i+1;
    }
    for(Student i:students) i.print();
}

int main(){
    
    test();  
}