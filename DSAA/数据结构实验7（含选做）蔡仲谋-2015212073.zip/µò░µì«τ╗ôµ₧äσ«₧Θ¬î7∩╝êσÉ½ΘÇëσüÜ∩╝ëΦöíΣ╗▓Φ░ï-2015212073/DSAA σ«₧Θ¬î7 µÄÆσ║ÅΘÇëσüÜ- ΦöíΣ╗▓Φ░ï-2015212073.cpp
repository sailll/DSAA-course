#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
#include <time.h>

using namespace std;

inline void exchange(int &x,int &y){
    if(x==y) return;
    int tmp = x;
    x = y;
    y = tmp;
}


void heapPush(int *heap,int &heapSize,int x,int &comparison,int move){
    int i=heapSize++;
    while(i>0){
        int p = (i-1)/2;
        comparison++;
        if(heap[p]<=x) break;
        heap[i] = heap[p];
        i=p;
    }
    move++;
    heap[i]=x;
}

int heapPop(int *heap,int &heapSize,int &comparison ,int &move){
    int ret = heap[0];
    int i = 0;
    int x = heap[--heapSize];
    while(i*2+1<heapSize){
        int left = i*2+1;
        int right = i*2+2;
        comparison+=2;
        if(right<heapSize&&heap[right]<heap[left]) left = right;
        if(heap[left]>=x) break;
        move++;
        heap[i] = heap[left];
        i = left;
    }
    heap[i] = x;
    return ret;
}

void heapSort(vector<int> array){
    cout<<"heap sort"<<endl;
    int comparison = 0;
    int move = 0;
    int heapSize = 0;
    int *heap = new int[array.size()];
    for(int i:array){
        heapPush(heap, heapSize, i, comparison, move);
    }
    for(int i=0;i<array.size();++i){
        move++;
        array[i]=heapPop(heap, heapSize, comparison, move);
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"num of comparison "<<comparison<<endl;
    cout<<"num of move "<<move<<endl;
    cout<<endl;
}

int binarySearch(vector<int> &array,int begin,int end,const int &key,int &comparison){
    int mid = (begin + end)/2;
    while(begin<=end){
        mid = begin + (end - begin)/2;
        comparison++;
        if(array[mid]<key) begin = mid+1;
        if(array[mid]>key) end = mid-1;
        if(array[mid]==key) return mid;
    }
    return begin;
}

void bin_insert(vector<int> &array,int begin,int end,int key,int &move){
    move+=end-begin+2;
    for(int i=end;i>=begin;--i){
        array[i+1]=array[i];
    }
    array[begin] = key;
}

void binary_insertion_sort(vector<int> array){
    cout<<"binary insertion sort"<<endl;
    int comparison = 0;
    int move = 0;
    for(int i=1;i<array.size();++i){
        int key = array[i];
        int begin = binarySearch(array, 0, i-1, key,comparison);
        bin_insert(array, begin, i-1, key,move);
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"num of comparison "<<comparison<<endl;
    cout<<"num of move "<<move<<endl;
    cout<<endl;
}

void shellSort(vector<int> array){
    cout<<"shell sort"<<endl;
    int comparison = 0 ;
    int move = 0;
    for(int gap = (int)array.size();gap>0;--gap){
        for(int i = gap;i<array.size();i+=gap){
            comparison++;
            for(int j = i;j>0&&array[j]<array[j-gap];j-=gap){
                move+=3;
                exchange(array[j], array[j-gap]);
            }
        }
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"num of comparison "<<comparison<<endl;
    cout<<"num of move "<<move<<endl;
    cout<<endl;
}


vector<int> merge(vector<int> &L,vector<int> &R,int &comparison,int &move){
    L.push_back(9999999);
    R.push_back(9999999);
    vector<int> ANS;
    int iofL=0;
    int iofR=0;
    for(int k=0;k<L.size()+R.size()-2;++k){
        comparison++;
        move++;
        if(L[iofL]<=R[iofR]){
            ANS.push_back(L[iofL]);
            ++iofL;
        }
        else{
            ANS.push_back(R[iofR]);
            ++iofR;
        }
    }
    return ANS;
}


void divide_conquer(vector<int> &array,int &comparison,int &move){
    if(array.size()>1){
        vector<int> L;
        vector<int> R;
        move+=array.size();
        for(int i=0;i<array.size()/2;++i){
            L.push_back(array[i]);
        }
        for(int i=(int)array.size()/2;i<array.size();++i){
            R.push_back(array[i]);
        }
        divide_conquer(L,comparison,move);
        divide_conquer(R,comparison,move);
        for(int i=0;i<array.size();i++){
            array[i]=merge(L,R,comparison,move)[i];
        }
    }
    else return ;
}

void callMergeSort(vector<int> array){
    cout<<"merge sort"<<endl;
    int comparison = 0;
    int move = 0;
    divide_conquer(array,comparison,move);
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"num of comparison "<<comparison<<endl;
    cout<<"num of move "<<move<<endl;
    cout<<endl;
}


int partition(vector<int> &ar,int bg,int ed,int &numOfComparison,int &numOfMove){
    int sen=ar[ed];
    int index=bg-1;
    for(int i=bg;i<ed;++i){
        numOfComparison++;
        if(ar[i]<sen){
            ++index;
            numOfMove+=3;
            exchange(ar[index],ar[i]);
        }
    }
    ++index;
    numOfMove+=3;
    exchange(ar[index],ar[ed]);
    return index;
}

void quicksort(vector<int> &ar,int bg,int ed,int &numOfComparison,int &numOfMove){
    if(bg<ed){
        int mid=partition(ar,bg,ed,numOfComparison,numOfMove);
        quicksort(ar,bg,mid-1,numOfComparison,numOfMove);
        quicksort(ar,mid+1,ed,numOfComparison,numOfMove);
    }
}

void callQuickSort(vector<int> array){
    cout<<"quick sort"<<endl;
    int numOfComparison = 0;
    int numOfMove = 0;
    quicksort(array, 0, (int)array.size()-1,numOfComparison,numOfMove);
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"num of comparison "<<numOfComparison<<endl;
    cout<<"num of move "<<numOfMove<<endl;
    cout<<endl;
}

void insertionSort(vector<int> array){
    cout<<"insertioin sort"<<endl;
    int len=(int)array.size();
    int numOfComparison = 0;
    int numOfMove = 0;
    for(int i=1;i<len;++i){
        int j=i;
        while(true){
            numOfComparison++;
            if(array[j]<array[j-1]&&j>=1){
                numOfMove+=3;
                exchange(array[j],array[j-1]);
                j--;
            }
            else break;
        }
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"number of comparion "<<numOfComparison<<endl;
    cout<<"nubmer of move "<<numOfMove<<endl;
    cout<<endl;
}

void selectionSort(vector<int> array){
    cout<<"selection sort"<<endl;
    int len = (int)array.size();
    int numberOfComparison = 0;
    int numberOfMove = 0;
    for(int i=0;i<len-1;++i){
        int minVal = array[i];
        int minKey = i;
        for(int j=i+1;j<len;++j){
            numberOfComparison+=2;
            if(minVal > array[j]){
                minVal = array[j];
                minKey = j;
            }
        }
        numberOfComparison++;
        if(i!=minKey){
            numberOfMove+=3;
            exchange(array[i], array[minKey]);
        }
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"number of Comparison "<<numberOfComparison<<endl;
    cout<<"number of move "<<numberOfMove<<endl;
    cout<<endl;
}

void bubbleSort(vector<int> array){
    
    cout<<"bubble sort"<<endl;
    int numOfComparison = 0;
    int numOfMove = 0;
    int len = (int)array.size();
    for(int i=0;i < len-1;++i){
        for(int j = 0;j<len-i-1;++j){
            numOfComparison++;
            if(array[j]>array[j+1]){
                numOfMove+=3;
                exchange(array[j], array[j+1]);
            }
            else continue;
        }
    }
//    for(int i:array) cout<<i<<" ";
    cout<<endl;
    cout<<"number of comparison "<<numOfComparison<<endl;
    cout<<"number of move "<<numOfMove<<endl;
    cout<<endl;
}


void test(int size){
    vector<int> array;
    for(int i=0;i<size;++i){
        array.push_back(rand()%100);
    }
    heapSort(array);
    binary_insertion_sort(array);
    shellSort(array);
    callMergeSort(array);
    callQuickSort(array);
    bubbleSort(array);
    insertionSort(array);
    selectionSort(array);
}

int main(){
    int size[]={10,50,100,500,1000};
    for(int i = 0;i<5;++i){
        test(size[i]);
    }
}

