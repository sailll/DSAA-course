#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <string>
char p[10005];//the pattern string
char s[1000005];//the search string
int next[10005];//the next array


void get_next(char str[],int len){//get the next array
    int k=0;
    next[1]=0;
    for(int i=2;i<=len;i++){
        while(k>0&&str[k+1]!=str[i])
            k=next[k];
        if(str[k+1]==str[i])
            k++;
        next[i]=k;
    }
}

void KMPmatch(char P[],int lenp,char T[],int lent){//the KMP matcher
    get_next(P,lenp);
    int k=0;
    for(int i=1;i<=lent;i++){
        while(k>0&&P[k+1]!=T[i])
            k=next[k];
        if(P[k+1]==T[i])
            k++;
        if(k==lenp){
            printf("%d ",i-lenp);
            k=next[k];
        }
    }
}

int main(){
    memset(next,0,sizeof(next));
    printf("enter the pattern string\n");
    scanf("%s",p+1);
    printf("enter the string to be search\n");
    scanf("%s",s+1);
    auto lenp=strlen(p+1);//get the length
    auto lens=strlen(s+1);
    KMPmatch(p,(int)lenp,s,(int)lens);
    getchar();
    return 0;
}