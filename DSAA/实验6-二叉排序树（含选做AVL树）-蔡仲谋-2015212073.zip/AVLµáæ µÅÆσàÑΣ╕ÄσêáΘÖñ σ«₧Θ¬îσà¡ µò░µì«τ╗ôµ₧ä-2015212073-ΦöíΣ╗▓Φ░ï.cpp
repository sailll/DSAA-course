#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
using namespace std;


void input(int n,vector<int> &key){//the input array process
    for(int i=0;i<n;++i){
        int cval;
        cin>>cval;
        key.push_back(cval);
    }
}

struct TreeNode // the structure for representing tree nodes
{
    int val;
    int height;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int k) { val = k; left = right = 0; height = 1; }
};

int height(TreeNode* p){
    return p ? p->height : 0;
}

int bfactor(TreeNode* p){
    return height(p->right) - height(p->left);
}

void fixheight(TreeNode* p){
    int hl = height(p->left);
    int hr = height(p->right);
    p->height = (hl>hr ? hl : hr) + 1;
}

void inorderTraversal(TreeNode* const &root){//the inorder traversal of a BST will return a ordered sequence
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}

TreeNode* rotateright(TreeNode* p){ // the right rotation round p
    TreeNode* q = p->left;
    p->left = q->right;
    q->right = p;
    fixheight(p);
    fixheight(q);
    return q;
}

TreeNode* rotateleft(TreeNode* q){ // the left rotation round q
    TreeNode* p = q->right;
    q->right = p->left;
    p->left = q;
    fixheight(q);
    fixheight(p);
    return p;
}

TreeNode* balance(TreeNode* p){ // p node balance
    fixheight(p);
    if( bfactor(p)==2 )
    {
        if( bfactor(p->right) < 0 )
            p->right = rotateright(p->right);
        return rotateleft(p);
    }
    if( bfactor(p)==-2 )
    {
        if( bfactor(p->left) > 0  )
            p->left = rotateleft(p->left);
        return rotateright(p);
    }
    return p; // no balance needed
}

TreeNode* insert(TreeNode* p, int k){ // k key insertion in the tree with p root
    if(!p) return new TreeNode(k);
    if( k<p->val )
        p->left = insert(p->left,k);
    else
        p->right = insert(p->right,k);
    return balance(p);
}

TreeNode* findmin(TreeNode* p){ // searching the node with the minimal key in p tree
    return p->left?findmin(p->left):p;
}

TreeNode* removemin(TreeNode* p){ // deleting the node with the minimal key from p tree
    if( p->left==0 )
        return p->right;
    p->left = removemin(p->left);
    return balance(p);
}

TreeNode* remove(TreeNode* p, int k){ // k key deletion from p tree
    if( !p ) return 0;
    if( k < p->val )
        p->left = remove(p->left,k);
    else if( k > p->val )
        p->right = remove(p->right,k);
    else{ //  k == p->key
        TreeNode* q = p->left;
        TreeNode* r = p->right;
        delete p;
        if( !r ) return q;
        TreeNode* min = findmin(r);
        min->right = removemin(r);
        min->left = q;
        return balance(min);
    }
    return balance(p);
}

    
//create the binary search tree
void createBST(TreeNode* &root,const vector<int> &array){
    if(array.size()==0) return;
    root->val=array[0];
    for(int i=1;i<array.size();++i){
        root=insert(root, array[i]);//insert and rebalance the tree
    }
    cout<<"the height of the root is "<<root->height<<endl;
}

int searchBST(TreeNode* &root,int key,int level=1){//search the given key value and return the search length
    if(!root){
        return -1;
    }
    if(key==root->val) return level;
    if(key>root->val) return searchBST(root->right, key,level+1);
    else return searchBST(root->left,key,level+1);
}


void testBST(){
    cout<<"enter the element to be searched"<<endl;
    int key;
    cin>>key;
    int n;
    cout<<"enter the length and an  array for BST"<<endl;
    cin>>n;
    vector<int> array;
    input(n, array);
    TreeNode *root=new TreeNode(0);
    createBST(root, array);
    cout<<"when the BST is created ,the inorderTraversal will be an increasing order sequence as follows"<<endl;
    inorderTraversal(root);
    cout<<endl;
    int k=searchBST(root, key);
    if(k>0)cout<<"it was found on level "<<k<<endl;
    else cout<<"not found"<<endl;
    cout<<"enter the value to be inserted"<<endl;
    int insVal;
    cin>>insVal;
    root=insert(root, insVal);
    cout<<"the tree inorderTraversal after the insertion"<<endl;
    inorderTraversal(root);
    cout<<endl;
    cout<<"enter the key value you want to delete,if it does not exist,nothing happens"<<endl;
    int del;
    cin>>del;
    root=remove(root,del);
    cout<<"the tree inorderTraversal after deletion"<<endl;
    inorderTraversal(root);
    cout<<endl;
}
int main(){
    testBST();
}
