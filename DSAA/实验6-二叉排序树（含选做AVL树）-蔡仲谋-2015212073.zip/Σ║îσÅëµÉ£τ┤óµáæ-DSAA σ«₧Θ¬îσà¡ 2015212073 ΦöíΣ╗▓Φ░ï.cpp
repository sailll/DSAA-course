#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <map>
using namespace std;


void input(int n,vector<int> &key){//the input array process
    for(int i=0;i<n;++i){
        int cval;
        cin>>cval;
        key.push_back(cval);
    }
}

template <class T>
class TreeNode{//define the treenode
    
public:
    T val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(T _val):val(_val),left(NULL),right(NULL){}
    TreeNode(){}
    
};


template <class T>
void inorderTraversal(TreeNode<T>* const &root){//the inorder traversal of a BST will return a ordered sequence
    if(!root) return ;
    inorderTraversal(root->left);
    cout<<root->val<<" ";
    inorderTraversal(root->right);
}


template <class T>//create the binary search tree
void createBST(TreeNode<T>* &root,const vector<T> &array){
    if(array.size()==0) return;
    root->val=array[0];
    for(int i=1;i<array.size();++i){
        auto pre=root;//use a pre pointer to denote the predecessor
        auto it=root;//use it to denote the current pointer
        bool flag=true;//use a flag to denote the right or the left
        while(it){
            if(array[i]>(it->val)) {
                flag=true;
                pre=it;
                it=it->right;
            }
            else{
                flag=false;
                pre=it;
                it=it->left;
            }
        }
        it=new TreeNode<T>(array[i]);
        if(flag) pre->right=it;
        else pre->left=it;
    }
}

template <class T>
int searchBST(TreeNode<T>* &root,T key,int level=1){
    if(!root){
        return -1;
    }
    if(key==root->val) return level;
    if(key>root->val) return searchBST(root->right, key,level+1);
    else return searchBST(root->left,key,level+1);
}



void testBST(){
    cout<<"enter the element to be searched"<<endl;
    int key;
    cin>>key;
    int n;
    cout<<"enter the length and an  array for BST"<<endl;
    cin>>n;
    vector<int> array;
    input(n, array);
    TreeNode<int> *root=new TreeNode<int>(0);
    createBST(root, array);
    cout<<"when the BST is created ,the inorderTraversal will be an increasing order sequence as follows"<<endl;
    inorderTraversal(root);
    cout<<endl;
    int k=searchBST(root, key);
    if(k>0)cout<<"it was found on level "<<k<<endl;
    else cout<<"not found"<<endl;
}
int main(){
    testBST();
}
